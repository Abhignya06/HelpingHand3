<?php
include("login.php"); 
if($_SESSION['name']==''){
	header("location: signup.php");
}
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="home.css">
    <link rel="stylesheet" href="profile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<header>
    <div class="logo">Helping<b style="color: #06C167;">Hands</b></div>
    <div class="hamburger">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
    <nav class="nav-bar">
        <ul>
            <li><a href="home.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
            <li><a href="profile.php" class="active">Profile</a></li>
            <li><a href="checkcampaign.php" >Donate to Campaigns</a></li>
            <li><a href="topdonors.php" >Donors</a></li>
        </ul>
    </nav>
</header>
<script>
    hamburger=document.querySelector(".hamburger");
    hamburger.onclick =function(){
        navBar=document.querySelector(".nav-bar");
        navBar.classList.toggle("active");
    }
</script>

<div class="profile">
    <div class="profilebox" style="">
        <p class="headingline" style="text-align: left;font-size:30px;"> <img src="" alt="" style="width:40px; height: 25px;; padding-right: 10px; position: relative;" >Profile</p>
        <br>
        <div class="info" style="padding-left:10px;">
            <p>Name  : <?php echo $_SESSION['name']; ?> </p><br>
            <p>Email : <?php echo $_SESSION['email']; ?> </p><br>
            <p>Gender: <?php echo $_SESSION['gender']; ?> </p><br>
            <a href="logout.php" style="float: left;margin-top: 6px ;border-radius:5px; background-color: #06C167; color: white;padding: ;padding-left: 10px;padding-right: 10px;">Logout</a>
        </div>
        <hr>
        <br>
        <p class="heading">Food donations</p>
        <div class="table-container">
            <div class="table-wrapper">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Food</th>
                            <th>Type</th>
                            <th>Category</th>
                            <th>Date/Time</th>
                            <th>Tacking Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $email = $_SESSION['email'];
                        $query = "SELECT * FROM food_donations WHERE email='$email'";
                        $result = mysqli_query($connection, $query);
                        if ($result == true) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr><td>".$row['food']."</td><td>".$row['type']."</td><td>".$row['category']."</td><td>".$row['date']."</td><td>".$row['status']."</td></tr>";

                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <p class="heading">Clothes donations</p>
<div class="table-container">
    <div class="table-wrapper">
        <table class="table">
            <thead>
                <tr>
                    <!-- <th>Clothes</th> -->
                    <th>Cloth Type</th>
                    <th>Gender</th>
                    <th>Age</th>
                    <th>Date/Time</th>
                    <th>Tacking Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $email = $_SESSION['email'];
                $query = "SELECT * FROM clothes_donations WHERE email='$email'";
                $result = mysqli_query($connection, $query);
                if ($result == true) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        // $clothes = isset($row['clothes']) ? $row['clothes'] : '';
                        $type = isset($row['type']) ? $row['type'] : '';
                        $gender = isset($row['gender']) ? $row['gender'] : '';
                        $age = isset($row['age']) ? $row['age'] : '';
                        $date = isset($row['date']) ? date('Y-m-d H:i:s', strtotime($row['date'])) : '';
                        $status=isset($row['status']) ? $row['status'] : '';
                        echo "<tr><td>$type</td><td>$gender</td><td>$age</td><td>$date</td><td>".$row['status']."</td></tr>";

                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
<!-- <p class="heading">Books Donations</p>
<div class="table-container">
    <div class="table-wrapper">
        <table class="table">
            <thead>
                <tr>
                    <th>Book Name</th>
                    <th>Standard</th>
                    <th>Quantity</th>
                    <th>Date/Time</th>
                   
                </tr>
            </thead>
            <tbody>
                 <?php
                $email = $_SESSION['email'];
                $query = "SELECT * FROM books_donations WHERE email='$email'";
                $result = mysqli_query($connection, $query);
                if ($result == true) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $bookname = isset($row['bookname']) ? $row['bookname'] : '';
                        $standard = isset($row['standard']) ? $row['standard'] : '';
                        $quantity = isset($row['quantity']) ? $row['quantity'] : '';
                        $date = isset($row['date']) ? date('Y-m-d H:i:s', strtotime($row['date'])) : '';
                        
                        echo "<tr><td>$bookname</td><td>$standard</td><td>$quantity</td><td>$date</td></tr>";
                    }
                }
                ?> 
            </tbody>
        </table>
    </div>
</div> -->


    </div>
</div>
</body>
</html>
