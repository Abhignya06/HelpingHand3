<?php
include("connection.php");

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Helping Hands</title>
    <style>
    body {
            margin: 0;
            padding: 0;
        }

        .background {
            background-image: url('blood.jpg');
            background-size: cover;
            background-position: center;
            height: 100vh; /* Set height to viewport height */
            position: relative;
        }

        .navbar-inside {
            width: 100%;
            background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent black */
            padding: 10px 0;
            color: white;
            display: flex;
            justify-content: center;
            position: absolute;
            top: 0; /* Position at the top of the image */
        }

        .navbar-inside ul {
            display: flex;
            list-style-type: none;
            padding: 0;
        }

        .navbar-inside ul li {
            margin-right: 20px;
        }

        .navbar-inside ul li a {
            color: white;
            text-decoration: none;
        }

        .navbar-inside ul li a:hover {
            color: #06C167;
        }

    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar navbar-dark bg-white">
        <a class="navbar-brand" href="#" style="color: black; font-size: 30px;"><div class="logo">Helping <b style="color: #06C167; font-size: 30px;">Hands</b></div></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item ">
              <a class="nav-link" href="index.html" style="color: black; font-size: 20px;">Home </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about1.html" style="color:black; font-size: 20px;">About</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="contact1.html "style="color: black; font-size: 20px;">Contact Us</a>
              </li>
              <li class="nav-item active">
                <a class="nav-link" href="bloodhome.php"style="color: black; font-size: 20px;">Donate Blood</a>
              </li>
          </ul>
          <div class="ms-auto p-3" >
            <!-- Login button that redirects to mainpage.html -->
                <button type="button" class="btn btn-danger" onclick="window.location.href='mainpage.html';" style="background-color: #06C167; font-size: 20px;">Login</button>      
        </div>
        </div>
      </nav>
      <div class="background">
        
        <nav class="navbar-inside">
            <span class="nav-item">
                <a class="nav-link" href="bloodhome.php" style="color: white;">Home</a>
            </span>
            <span class="nav-item">
                <a class="nav-link" href="blood_find.php" style="color: white;">Find Donor</a>
            </span>
            <span class="nav-item">
                <a class="nav-link" href="blood_register.php" style="color: white;" active>Donate</a>
            </span>
        </nav>
       
      </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
