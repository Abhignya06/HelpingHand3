<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f8f8f8;
        }
        .success-container {
            text-align: center;
            margin-top: 100px;
        }
        .tick-mark {
            font-size: 100px;
            color: #4CAF50;
        }
        .success-message {
            font-size: 24px;
            color: #4CAF50;
            margin-bottom: 20px;
        }
        .thank-you-message {
            font-size: 20px;
            color: #333333;
        }
        .home-button {
            position: absolute;
            top: 10px;
            left: 10px;
            background-color: #2196F3;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .home-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <a href="home.html" class="home-button">Home</a>
    <div class="success-container">
        <div class="tick-mark">&#10004;</div>
        <div class="success-message">Payment Successful</div>
        <div class="thank-you-message">Thank you for your contribution to the great cause.</div>
    </div>
</body>
</html>
