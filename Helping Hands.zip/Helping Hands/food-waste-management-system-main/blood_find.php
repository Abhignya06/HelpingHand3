<?php
include("connection.php");

// Define an empty variable to store the table content
$tableContent = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $bloodgroup = $_POST["bloodgroup"];

    // Retrieve donors with the selected blood group
    $sql = "SELECT * FROM donors WHERE bloodgroup = '$bloodgroup'";
    $result = mysqli_query($connection, $sql);

    $tableContent .= "<div class='container mt-5'>";
    $tableContent .= "<h2 style='color: white;'>Donors with Blood Group $bloodgroup</h2>";

    $tableContent .= "<table class='table table-dark table-striped'>";
    $tableContent .= "<thead>";
    $tableContent .= "<tr>";
    $tableContent .= "<th>ID</th>";
    $tableContent .= "<th>Full Name</th>";
    $tableContent .= "<th>Date of Birth</th>";
    $tableContent .= "<th>Gender</th>";
    $tableContent .= "<th>Blood Group</th>";
    $tableContent .= "<th>Mobile</th>";
    $tableContent .= "<th>Email</th>";
    $tableContent .= "<th>Town</th>";
    $tableContent .= "<th>State</th>";
    $tableContent .= "<th>Last Donation Date</th>";
    $tableContent .= "</tr>";
    $tableContent .= "</thead>";
    $tableContent .= "<tbody>";

    while ($row = mysqli_fetch_assoc($result)) {
        $tableContent .= "<tr>";
        $tableContent .= "<td>{$row['id']}</td>";
        $tableContent .= "<td>{$row['fullname']}</td>";
        $tableContent .= "<td>{$row['dob']}</td>";
        $tableContent .= "<td>{$row['sex']}</td>";
        $tableContent .= "<td>{$row['bloodgroup']}</td>";
        $tableContent .= "<td>{$row['mobile']}</td>";
        $tableContent .= "<td>{$row['email']}</td>";
        $tableContent .= "<td>{$row['town']}</td>";
        $tableContent .= "<td>{$row['state']}</td>";
        $tableContent .= "<td>{$row['lastdate']}</td>";
        $tableContent .= "</tr>";
    }

    $tableContent .= "</tbody>";
    $tableContent .= "</table>";
    $tableContent .= "</div>";

    mysqli_free_result($result);
}

mysqli_close($connection);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Helping Hands</title>
    <style>
    body {
            margin: 0;
            padding: 0;
        }

        .background {
            background-image: url('blood.jpg');
            background-size: cover;
            background-position: center;
            height: 100vh; /* Set height to viewport height */
            position: relative;
            display: flex;
            justify-content: center; /* Center content horizontally */
            align-items: center; /* Center content vertically */
            flex-direction: column; /* Align items in a column */
        }

        .navbar-inside {
            width: 100%;
            background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent black */
            padding: 10px 0;
            color: white;
            display: flex;
            justify-content: center;
            position: absolute;
            top: 0; /* Position at the top of the image */
        }

        .navbar-inside ul {
            display: flex;
            list-style-type: none;
            padding: 0;
        }

        .navbar-inside ul li {
            margin-right: 20px;
        }

        .navbar-inside ul li a {
            color: white;
            text-decoration: none;
        }

        .navbar-inside ul li a:hover {
            color: #06C167;
        }

    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar navbar-dark bg-white">
        <!-- Your first navbar content here -->
        <a class="navbar-brand" href="#" style="color: black; font-size: 30px;"><div class="logo">Helping <b style="color: #06C167; font-size: 30px;">Hands</b></div></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item ">
              <a class="nav-link" href="index.html" style="color: black; font-size: 20px;">Home </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about1.html" style="color:black; font-size: 20px;">About</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="contact1.html "style="color: black; font-size: 20px;">Contact Us</a>
              </li>
              <li class="nav-item active">
                <a class="nav-link" href="bloodhome.php"style="color: black; font-size: 20px;">Donate Blood</a>
              </li>
          </ul>
          <div class="ms-auto p-3" >
            <!-- Login button that redirects to mainpage.html -->
                <button type="button" class="btn btn-danger" onclick="window.location.href='mainpage.html';" style="background-color: #06C167; font-size: 20px;">Login</button>      
        </div>
        </div>
    </nav>
    <div class="background">
        <nav class="navbar-inside">
            <span class="nav-item">
                <a class="nav-link" href="bloodhome.php" style="color: white;">Home</a>
            </span>
            <span class="nav-item">
                <a class="nav-link" href="blood_find.php" style="color: white;">Find Donor</a>
            </span>
            <span class="nav-item">
                <a class="nav-link" href="blood_register.php" style="color: white;" active>Donate</a>
            </span>
        </nav>
        <div>
            <form action="blood_find.php" method="post">
                <label for="bloodgroup" style="color: white;">Find Donor:</label>
                <select name="bloodgroup" id="bloodgroup" required>
                    <option value="">Select Blood Group</option>
                    <option value="A pos">A+</option>
                    <option value="A neg">A-</option>
                    <option value="B pos">B+</option>
                    <option value="B neg">B-</option>
                    <option value="O pos">O+</option>
                    <option value="O neg">O-</option>
                    <option value="AB pos">AB+</option>
                    <option value="AB neg">AB-</option>
                </select>
                <input type="submit" value="Search" class="btn btn-primary">
            </form>
        </div>
        <?php
        // Display the table content
        echo $tableContent;
        ?>
    </div>
    <nav class="navbar navbar-expand-lg navbar navbar-dark bg-white">
        <!-- Your second navbar content here -->
    </nav>
    <!-- Rest of your content -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
