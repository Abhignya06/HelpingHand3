<?php
session_start();
include 'connection.php';

if (isset($_POST['send'])) {
    $email = $_POST['email'];
    $name = $_POST['name'];
    $msg = $_POST['message'];
    $sanitized_emailid =  mysqli_real_escape_string($connection, $email);
    $sanitized_name =  mysqli_real_escape_string($connection, $name);
    $sanitized_msg =  mysqli_real_escape_string($connection, $msg);
    $query="insert into user_feedback(name,email,message) values('$sanitized_name','$sanitized_emailid','$sanitized_msg')";
    $query_run= mysqli_query($connection, $query);
    if($query_run) {
        echo '<script type="text/javascript">alert("Feedback added successfully!"); window.location.href="contact.html";</script>';
    } else {
        echo '<script type="text/javascript">alert("Failed to add feedback. Please try again.");</script>';
    }
}
?>
