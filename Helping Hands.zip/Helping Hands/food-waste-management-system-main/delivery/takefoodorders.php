<?php
include("connect.php");
include '../connection.php';

if ($_SESSION['name'] == '') {
    header("location:deliverylogin.php");
    exit;
}

$name = $_SESSION['name'];
$id = $_SESSION['Did'];
$city = $_SESSION['city'];

// Fetch all unassigned food orders in the user's city
$sql = "SELECT fd.Fid AS Fid, fd.location as cure, fd.name, fd.phoneno, fd.date, fd.delivery_by, fd.address as From_address, 
                ad.name AS delivery_person_name, ad.address AS To_address
                FROM food_donations fd
                LEFT JOIN admin ad ON fd.assigned_to = ad.Aid 
                WHERE assigned_to IS NULL AND delivery_by IS NULL AND fd.location='$city'";

$result = mysqli_query($connection, $sql);

// Check for errors
if (!$result) {
    die("Error executing query: " . mysqli_error($connection));
}

// Fetch the unassigned food donation data as an associative array
$data_food = array();
while ($row_food = mysqli_fetch_assoc($result)) {
    $data_food[] = $row_food;
}

// Fetch delivery addresses from d_address table
$sql_addresses = "SELECT * FROM d_address";
$result_addresses = mysqli_query($connection, $sql_addresses);

// Check for errors
if (!$result_addresses) {
    die("Error executing query: " . mysqli_error($connection));
}

// Fetch the delivery addresses as an associative array
$addresses = array();
while ($row_address = mysqli_fetch_assoc($result_addresses)) {
    $addresses[] = $row_address['address'];
}

// If the delivery person takes an order, update the assigned_to and delivery_by fields in the database
if (isset($_POST['food']) && isset($_POST['delivery_person_id'])) {
    $order_id = $_POST['order_id'];
    $delivery_person_id = $_POST['delivery_person_id'];
    $delivery_address = $_POST['delivery_address'];

    // Check if the order has already been assigned to someone else
    $sql_check = "SELECT * FROM food_donations WHERE Fid = $order_id AND delivery_by IS NOT NULL";
    $result_check = mysqli_query($connection, $sql_check);

    if (mysqli_num_rows($result_check) > 0) {
        // Order has already been assigned to someone else
        die("Sorry, this order has already been assigned to someone else.");
    }

    // Update the database with the new assignment and delivery address
    $sql_update = "UPDATE food_donations SET assigned_to = $delivery_person_id, delivery_by = $delivery_person_id, delivery_address = '$delivery_address' WHERE Fid = $order_id";
    $result_update = mysqli_query($connection, $sql_update);

    if (!$result_update) {
        die("Error assigning order: " . mysqli_error($connection));
    }

    // Reload the page to prevent duplicate assignments
    header('Location: ' . $_SERVER['REQUEST_URI']);
    exit;
}

mysqli_close($connection);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Take Food Orders</title>
    <link rel="stylesheet" href="../home.css">
    <link rel="stylesheet" href="delivery.css">
    <style>
        select[name="delivery_address"] {
            width: 100%;
            box-sizing: border-box;
        }
    </style>
</head>
<body>
<header>
    <div class="logo">Helping <b style="color: #06C167;"> Hands</b></div>
    <div class="hamburger">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
    <nav class="nav-bar">
        <ul>
            <li><a href="delivery.php" class="active">Home</a></li>
            <li><a href="openmap.php">Map</a></li>
            <li><a href="foodmyord.php">My Food Orders</a></li>
        </ul>
    </nav>
</header>
<br>
<h2><center>Welcome <?php echo "$name"; ?></center></h2>

<div class="table-container">
    <div class="table-wrapper">
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone Number</th>
                    <th>Date/Time</th>
                    <th>Pickup Address</th>
                    <th>Delivery Address</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data_food as $row_food) { ?>
                    <tr>
                        <td><?= $row_food['name'] ?></td>
                        <td><?= $row_food['phoneno'] ?></td>
                        <td><?= $row_food['date'] ?></td>
                        <td><?= $row_food['From_address'] ?></td>
                        <td>
                            <select name="delivery_address">
                                <?php foreach ($addresses as $address) { ?>
                                    <option value="<?= $address ?>"><?= $address ?></option>
                                <?php } ?>
                            </select>
                        </td>
                        <td data-label="Action">
                            <form method="post" action="">
                                <input type="hidden" name="order_id" value="<?= $row_food['Fid'] ?>">
                                <input type="hidden" name="delivery_person_id" value="<?= $id ?>">
                                <input type="hidden" name="delivery_address" value="<?= $address ?>">
                                <button type="submit" name="food">Take Order</button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
