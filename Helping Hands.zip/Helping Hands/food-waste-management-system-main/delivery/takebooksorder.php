<?php
include("connect.php");
include '../connection.php';

if ($_SESSION['name'] == '') {
    header("location:deliverylogin.php");
    exit;
}

$name = $_SESSION['name'];
$id = $_SESSION['Did'];
$city = $_SESSION['city'];



// Fetch all unassigned clothes orders in the user's city
$sql = "SELECT bd.bid AS bid, bd.location as cure, bd.name, bd.phoneno, bd.date, bd.delivery_by, bd.address as From_address, 
                ad.name AS delivery_person_name, ad.address AS To_address
                FROM books_donations bd
                LEFT JOIN admin ad ON bd.assigned_to = ad.Aid 
                WHERE assigned_to IS NULL AND delivery_by IS NULL AND bd.location='$city'";

$result = mysqli_query($connection, $sql);

// Check for errors
if (!$result) {
    die("Error executing query: " . mysqli_error($connection));
}

// Fetch the unassigned clothes donation data as an associative array
$data_books = array();
while ($row_books = mysqli_fetch_assoc($result)) {
    $data_books[] = $row_books;
}

// Fetch delivery addresses from d_address table
$sql_addresses = "SELECT CONCAT('Delivered to ', address) AS address FROM d_address";
$result_addresses = mysqli_query($connection, $sql_addresses);
// Check for errors
if (!$result_addresses) {
    die("Error executing query: " . mysqli_error($connection));
}

// Fetch the delivery addresses as an associative array
$addresses = array();
while ($row_address = mysqli_fetch_assoc($result_addresses)) {
    $addresses[] = $row_address;
}

// If the delivery person takes an order, update the assigned_to, delivery_by, and delivery_add fields in the database
if (isset($_POST['take_order']) && isset($_POST['order_id']) && isset($_POST['delivery_address'])) {
    $order_id = $_POST['order_id'];
    $delivery_address = $_POST['delivery_address'];

    echo "Order ID: $order_id<br>";
    echo "Delivery Address: $delivery_address<br>";

    // Update the database with the new assignment and delivery address
    $sql_update = "UPDATE books_donations SET assigned_to = $id, delivery_by = $id, delivery_add = '$delivery_address', status = CONCAT('Delivered to ', '$delivery_address') WHERE bid = $order_id";

    $result_update = mysqli_query($connection, $sql_update);

    if (!$result_update) {
        die("Error assigning order: " . mysqli_error($connection));
    }

    // Redirect to clothesmyord.php
    header('Location: booksmyord.php');
    exit;
}

mysqli_close($connection);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Take Book Orders</title>
    <link rel="stylesheet" href="../home.css">
    <link rel="stylesheet" href="delivery.css">
    <style>
        select[name="delivery_address"] {
            width: 100%;
            box-sizing: border-box;
        }
    </style>
</head>
<body>
<header>
    <div class="logo">Helping <b style="color: #06C167;"> Hands</b></div>
    <div class="hamburger">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
    <nav class="nav-bar">
        <ul>
            <li><a href="delivery.php" class="active">Home</a></li>
            <li><a href="openmap.php">Map</a></li>
            <li><a href="booksmyord.php">My Books Orders</a></li>
        </ul>
    </nav>
</header>
<br>
<h2><center>Welcome <?php echo "$name"; ?></center></h2>

<div class="table-container">
    <div class="table-wrapper">
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone Number</th>
                    <th>Date/Time</th>
                    <th>Pickup Address</th>
                    <th>Delivery Address</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data_books as $row_books) { ?>
                    <tr>
                        <td><?= $row_books['name'] ?></td>
                        <td><?= $row_books['phoneno'] ?></td>
                        <td><?= $row_books['date'] ?></td>
                        <td><?= $row_books['From_address'] ?></td>
                        <td>
                            <form method="post" action="">
                                <input type="hidden" name="order_id" value="<?= $row_book['bid'] ?>">
                                <select name="delivery_address">
                                    <option value="select_address">Select Address</option>
                                    <?php foreach ($addresses as $address) { ?>
                                        <option value="<?= $address['address'] ?>"><?= $address['address'] ?></option>
                                    <?php } ?>
                                </select>
                        </td>
                        <td data-label="Action">
                            <button type="submit" name="take_order">Take Order</button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
