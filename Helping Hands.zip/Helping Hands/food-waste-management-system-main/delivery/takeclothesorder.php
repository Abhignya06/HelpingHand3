<?php
include("connect.php");
include '../connection.php';

if ($_SESSION['name'] == '') {
    header("location:deliverylogin.php");
    exit;
}

$name = $_SESSION['name'];
$id = $_SESSION['Did'];
$city = $_SESSION['city'];

// Fetch all unassigned clothes orders in the user's city
$sql = "SELECT cd.cid AS cid, cd.location as cure, cd.name, cd.phoneno, cd.date, cd.delivery_by, cd.address as From_address, 
                ad.name AS delivery_person_name, ad.address AS To_address
                FROM clothes_donations cd
                LEFT JOIN admin ad ON cd.assigned_to = ad.Aid 
                WHERE assigned_to IS NULL AND delivery_by IS NULL AND cd.location='$city'";

$result = mysqli_query($connection, $sql);

// Check for errors
if (!$result) {
    die("Error executing query: " . mysqli_error($connection));
}

// Fetch the unassigned clothes donation data as an associative array
$data_clothes = array();
while ($row_clothes = mysqli_fetch_assoc($result)) {
    $data_clothes[] = $row_clothes;
}

// Fetch delivery addresses from d_address table
$sql_addresses = "SELECT CONCAT('Delivered to ', address) AS address FROM d_address";
$result_addresses = mysqli_query($connection, $sql_addresses);
// Check for errors
if (!$result_addresses) {
    die("Error executing query: " . mysqli_error($connection));
}

// Fetch the delivery addresses as an associative array
$addresses = array();
while ($row_address = mysqli_fetch_assoc($result_addresses)) {
    $addresses[] = $row_address;
}

// If the delivery person takes an order, update the assigned_to, delivery_by, and delivery_add fields in the database
if (isset($_POST['take_order']) && isset($_POST['order_id']) && isset($_POST['delivery_address'])) {
    $order_id = $_POST['order_id'];
    $delivery_address = $_POST['delivery_address'];

    // Update the database with the new assignment and delivery address
    $sql_update = "UPDATE clothes_donations SET assigned_to = $id, delivery_by = $id, delivery_add = '$delivery_address', status = CONCAT('Delivered to ', '$delivery_address') WHERE cid = $order_id";

    $result_update = mysqli_query($connection, $sql_update);

    if (!$result_update) {
        die("Error assigning order: " . mysqli_error($connection));
    }

    // Redirect to clothesmyord.php
    header('Location: clothesmyord.php');
    exit;
}

mysqli_close($connection);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Take Clothes Orders</title>
    <link rel="stylesheet" href="../home.css">
    <link rel="stylesheet" href="delivery.css">
    <style>
        select[name="delivery_address"] {
            width: 100%;
            box-sizing: border-box;
        }
    </style>
</head>
<body>
<header>
    <div class="logo">Helping <b style="color: #06C167;"> Hands</b></div>
    <div class="hamburger">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
    <nav class="nav-bar">
        <ul>
            <li><a href="delivery.php" class="active">Home</a></li>
            <li><a href="openmap.php">Map</a></li>
            <li><a href="clothesmyord.php">My Clothes Orders</a></li>
        </ul>
    </nav>
</header>
<br>
<h2><center>Welcome <?php echo "$name"; ?></center></h2>

<div class="table-container">
    <div class="table-wrapper">
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone Number</th>
                    <th>Date/Time</th>
                    <th>Pickup Address</th>
                    <th>Delivery Address</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data_clothes as $row_clothes) { ?>
                    <tr>
                        <td><?= $row_clothes['name'] ?></td>
                        <td><?= $row_clothes['phoneno'] ?></td>
                        <td><?= $row_clothes['date'] ?></td>
                        <td><?= $row_clothes['From_address'] ?></td>
                        <td>
                            <form method="post" action="">
                                <input type="hidden" name="order_id" value="<?= $row_clothes['cid'] ?>">
                                <select name="delivery_address">
                                    <option value="select_address">Select Address</option>
                                    <?php foreach ($addresses as $address) { ?>
                                        <option value="<?= $address['address'] ?>"><?= $address['address'] ?></option>
                                    <?php } ?>
                                </select>
                        </td>
                        <td data-label="Action">
                            <button type="submit" name="take_order">Take Order</button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
