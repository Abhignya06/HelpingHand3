<?php
ob_start();
include("connect.php");
include '../connection.php';

if ($_SESSION['name'] == '') {
    header("location:deliverylogin.php");
    exit;
}
$name = $_SESSION['name'];
$id = $_SESSION['Did'];

// Fetch clothes orders assigned to the current delivery person
$sql_assigned_clothes = "SELECT cd.cid AS cid, cd.location as cure, cd.name, cd.phoneno, cd.date, cd.delivery_by, cd.address as From_address, 
                ad.name AS delivery_person_name, ad.address AS To_address, cd.delivery_add, cd.status
                FROM clothes_donations cd
                LEFT JOIN admin ad ON cd.assigned_to = ad.Aid 
                WHERE assigned_to = $id
                ORDER BY cd.date DESC";

$result_assigned_clothes = mysqli_query($connection, $sql_assigned_clothes);

// Check for errors
if (!$result_assigned_clothes) {
    die("Error executing query: " . mysqli_error($connection));
}

// Fetch the assigned clothes orders data as an associative array
$data_assigned_clothes = array();
while ($row_assigned_clothes = mysqli_fetch_assoc($result_assigned_clothes)) {
    $data_assigned_clothes[] = $row_assigned_clothes;
}

// Update status if form is submitted
// Update status if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cid = $_POST['cid'];
    $status = $_POST['status'];

    // Check if status is "donation picked" or "on the way"
    if ($status == "donation picked" || $status == "on the way") {
        $status_value = $status;
    } else {
        // Extract the delivery address from the selected option
        $delivery_address = substr($status, 13); // Remove "Delivered to " from the selected option
        $status_value = "delivered to " . $delivery_address;
    }

    // Update the status in the database
    $update_sql = "UPDATE clothes_donations SET status = '$status_value' WHERE cid = $cid";
    if (mysqli_query($connection, $update_sql)) {
        // Redirect to prevent form resubmission
        header("Location: ".$_SERVER['PHP_SELF']);
        exit;
    } else {
        echo "Error updating record: " . mysqli_error($connection);
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Clothes Orders</title>
    <link rel="stylesheet" href="../home.css">
    <link rel="stylesheet" href="delivery.css">
    <style>
        select[name="status"] {
            width: 100%;
            box-sizing: border-box;
        }
    </style>
</head>
<body>
<header>
    <div class="logo">Clothes Donation Dashboard</div>
    <div class="hamburger">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
    <nav class="nav-bar">
        <ul>
            <li><a href="delivery.php">Home</a></li>
            <li><a href="openmap.php">Map</a></li>
            <li><a href="deliverymyord.php" class="active">My Clothes Orders</a></li>
        </ul>
    </nav>
</header>
<br>
<h2><center>Welcome <?php echo "$name"; ?></center></h2>

<div class="table-container">
    <div class="table-wrapper">
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone Number</th>
                    <th>Date/Time</th>
                    <th>Pickup Address</th>
                    <th>Delivery Address</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data_assigned_clothes as $row_assigned_clothes) { ?>
                    <tr>
                        <td><?= $row_assigned_clothes['name'] ?></td>
                        <td><?= $row_assigned_clothes['phoneno'] ?></td>
                        <td><?= $row_assigned_clothes['date'] ?></td>
                        <td><?= $row_assigned_clothes['From_address'] ?></td>
                        <td><?= $row_assigned_clothes['delivery_add'] ?></td>
                        <td>
                            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                                <input type="hidden" name="cid" value="<?= $row_assigned_clothes['cid'] ?>">
                                <select name="status">
                                    <option value="donation picked" <?php if ($row_assigned_clothes['status'] == "donation picked") echo "selected"; ?>>Donation Picked</option>
                                    <option value="on the way" <?php if ($row_assigned_clothes['status'] == "on the way") echo "selected"; ?>>On the Way</option>
                                    <option value="delivered to <?= $row_assigned_clothes['From_address'] ?>" <?php if (strpos($row_assigned_clothes['status'], "delivered to") !== false) echo "selected"; ?>>Delivered to <?= $row_assigned_clothes['From_address'] ?></option>
                                </select>
                                <button type="submit">Update</button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
