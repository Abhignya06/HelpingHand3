<?php
ob_start();
include("connect.php");
include '../connection.php';

if ($_SESSION['name'] == '') {
    header("location:deliverylogin.php");
}
$name = $_SESSION['name'];
$id = $_SESSION['Did'];

// Fetch book orders assigned to the current delivery person
$sql_assigned_books = "SELECT bd.bid AS bid, bd.location AS cure, bd.name, bd.phoneno, bd.date, bd.delivery_by, bd.address AS From_address, 
                ad.name AS delivery_person_name, ad.address AS To_address
                FROM books_donations bd
                LEFT JOIN admin ad ON bd.assigned_to = ad.Aid 
                WHERE assigned_to = $id
                ORDER BY bd.date DESC";

$result_assigned_books = mysqli_query($connection, $sql_assigned_books);

// Check for errors
if (!$result_assigned_books) {
    die("Error executing query: " . mysqli_error($connection));
}

// Fetch the assigned book orders data as an associative array
$data_assigned_books = array();
while ($row_assigned_books = mysqli_fetch_assoc($result_assigned_books)) {
    $data_assigned_books[] = $row_assigned_books;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Book Orders</title>
    <link rel="stylesheet" href="../home.css">
    <link rel="stylesheet" href="delivery.css">
</head>
<body>
<header>
    <div class="logo">Book Donation Dashboard</div>
    <div class="hamburger">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
    <nav class="nav-bar">
        <ul>
            <li><a href="delivery.php">Home</a></li>
            <li><a href="openmap.php">Map</a></li>
            <li><a href="deliverymyord.php" class="active">My Book Orders</a></li>
        </ul>
    </nav>
</header>
<br>
<h2><center>Welcome <?php echo "$name"; ?></center></h2>

<div class="table-container">
    <div class="table-wrapper">
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone Number</th>
                    <th>Date/Time</th>
                    <th>Pickup Address</th>
                    <th>Delivery Address</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data_assigned_books as $row_assigned_books) { ?>
                    <tr>
                        <td><?= $row_assigned_books['name'] ?></td>
                        <td><?= $row_assigned_books['phoneno'] ?></td>
                        <td><?= $row_assigned_books['date'] ?></td>
                        <td><?= $row_assigned_books['From_address'] ?></td>
                        <td><?= $row_assigned_books['To_address'] ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
