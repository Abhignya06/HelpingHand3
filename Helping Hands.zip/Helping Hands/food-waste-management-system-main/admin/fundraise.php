<?php
include("connect.php");
if ($_SESSION['name'] == '') {
    header("location:signin.php");
}

if(isset($_POST['view_funds'])) {
    $campaign_id = $_POST['campaign_id'];

    // Retrieve campaign details
    $query = "SELECT * FROM campaigns WHERE id = $campaign_id";
    $result = mysqli_query($connection, $query);
    $campaign = mysqli_fetch_assoc($result);

    $required_amount = $campaign['amount_needed'];
    $amount_raised_query = "SELECT required_amount AS total_amount FROM campaigns WHERE id = $campaign_id";
    $amount_raised_result = mysqli_query($connection, $amount_raised_query);
    $amount_raised_row = mysqli_fetch_assoc($amount_raised_result);
    $amount_raised = $amount_raised_row['total_amount'];
    $remaining_amount = $required_amount - $amount_raised;
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Funds Raised</title>
    </head>
    <body>
        <h1>Funds Raised for <?php echo $campaign['campaign_name']; ?></h1>
        <p>Total Amount Needed: $<?php echo $amount_raised;?></p>
        <p>Amount Raised:  $<?php echo $remaining_amount; ?></p>
        <p>Remaining Amount Needed: $<?php echo $required_amount; ?></p>
        <a href="campaign.php">Back to Campaigns</a>
       
        
    </body>
    </html>

    <?php
}
?>