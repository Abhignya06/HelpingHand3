<?php
$conn = mysqli_connect("localhost", "root", "");
$db = mysqli_select_db($conn, 'demo');

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process the form data and display the payment section
    $bankName = $_POST['bank_name'];
    $mobileNumber = $_POST['mobile_number'];
    $amountToDonate = $_POST['amount_to_donate'];
    $donorName = $_POST['donor_name'];
    $campaign_id = $_POST['campaign_id'];

    // Insert donation details into the database
    $sql = "INSERT INTO donations_user (mobile, account_holder, amount, campaign_id) VALUES ('$mobileNumber', '$donorName', '$amountToDonate', '$campaign_id')";
    if ($conn->query($sql) === TRUE) {
        // Update the campaign's amount_raised and amount_needed
        $query = "SELECT * FROM campaigns WHERE id = $campaign_id";
        $result = mysqli_query($conn, $query);
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $amount_raised = $row['amount_raised'] + $amountToDonate;
            $amount_needed = $row['amount_needed'] - $amountToDonate;

            $update_query = "UPDATE campaigns SET amount_raised = $amount_raised, amount_needed = $amount_needed WHERE id = $campaign_id";
            if (mysqli_query($conn, $update_query)) {
                // Update successful
                echo "Donation successfully processed.";
            } else {
                // Update failed
                echo "Error updating campaign: " . mysqli_error($conn);
            }
        } else {
            echo "Campaign not found.";
        }
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Donate</title>
    <style>
        /* Your CSS styles here */
        /* CSS styles from the original code */
        /* CSS styles from the original code */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        form {
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin-bottom: 10px;
        }
        input[type="text"],
        select {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        body {
            height: 100vh;
            background-image: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 0)), url("background.jpg");
            background-size: cover;
            background-position: center;
            margin: 0 10px;
        }
        .payment {
            background: #f8f8f8;
            max-width: 360px;
            margin: 80px auto;
            height: auto;
            padding: 70px 35px 35px;
            border-radius: 5px;
            position: relative;
        }
        .payment h2 {
            text-align: center;
            letter-spacing: 2px;
            margin-bottom: 40px;
            color: #0d3c61;
        }
        .payment h3 {
            text-align: center;
            margin-bottom: 40px;
            color: #0d3c61;
        }
        .form .label {
            display: block;
            color: #555555;
            margin-bottom: 6px;
        }
        .input {
            padding: 13px 0 13px 25px;
            width: 100%;
            text-align: center;
            border: 2px solid #dddddd;
            border-radius: 5px;
            letter-spacing: 1px;
            word-spacing: 3px;
            outline: none;
            font-size: 16px;
            color: #555555;
        }
        .card-grp {
            display: flex;
            justify-content: space-between;
        }
        .card-item {
            width: 48%;
        }
        .space {
            margin-bottom: 20px;
        }
        .icon-relative {
            position: relative;
        }
        .icon-relative .fas, .icon-relative .far {
            position: absolute;
            bottom: 12px;
            left: 15px;
            font-size: 20px;
            color: #555555;
        }
        .btn {
            margin-top: 40px;
            background: #2196F3;
            padding: 12px;
            text-align: center;
            color: #f8f8f8;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .payment-logo {
            position: absolute;
            top: -50px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 100px;
            background: #f8f8f8;
            border-radius: 50%;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
            text-align: center;
            line-height: 85px;
        }
        .payment-logo:before {
            content: "";
            position: absolute;
            top: 5px;
            left: 5px;
            width: 90px;
            height: 90px;
            background: #2196F3;
            border-radius: 50%;
        }
        .payment-logo p {
            position: relative;
            color: #f8f8f8;
            font-family: 'Baloo Bhaijaan', cursive;
            font-size: 58px;
        }
        @media screen and (max-width: 420px) {
            .card-grp {
                flex-direction: column;
            }
            .card-item {
                width: 100%;
                margin-bottom: 20px;
            }
            .btn {
                margin-top: 20px;
            }
        }

    </style>
</head>
<body>
    <form method="post" id="payment-form">
        <label for="bank_name">Select Bank:</label>
        <select id="bank_name" name="bank_name" required>
            <option value="Bank 1">STATE BANK OF INDIA</option>
            <option value="Bank 2">UNION BANK</option>
            <option value="Bank 3">HDFC BANK</option>
            <option value="Bank 4">CANARA BANK</option>
            <!-- Add more options for other banks -->
        </select>

        <label for="mobile_number">Mobile Number:</label>
        <input type="text" id="mobile_number" name="mobile_number" required>
        
        <label for="amount_to_donate">Amount to Donate:</label>
        <input type="text" id="amount_to_donate" name="amount_to_donate" required>
        <label for="donor_name">Donor Name:</label>
        <input type="text" id="donor_name" name="donor_name" required>
        <input type="hidden" name="campaign_id" value="<?php echo $_GET['campaign_id']; ?>">
    
        <input type="submit" value="Donate">
    </form>

    <!-- Payment Checkout Form -->
    <div id="payment" style="display: none;">
        <div class="wrapper">
            <div class="payment">
                <div class="payment-logo">
                    <p>p</p>
                </div>
                <h2>Payment Gateway</h2>
                <!-- Your payment form code here -->
                <div class="form">
                    <div class="card space icon-relative">
                        <label class="label">Card holder:</label>
                        <label>
                            <input type="text" class="input" placeholder="Card holder's Name">
                        </label>
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="card space icon-relative">
                        <label class="label">Card number:</label>
                        <label>
                            <input type="text" class="input" data-mask="0000 0000 0000 0000" placeholder="Card Number">
                        </label>
                        <i class="far fa-credit-card"></i>
                    </div>
                    <div class="card-grp space">
                        <div class="card-item icon-relative">
                            <label class="label">Expiry date:</label>
                            <label>
                                <input type="text" name="expiry-data" class="input" data-mask="00 / 00" placeholder="00 / 00">
                            </label>
                            <i class="far fa-calendar-alt"></i>
                        </div>
                        <div class="card-item icon-relative">
                            <label class="label">CVV:</label>
                            <label>
                                <input type="password" class="input" data-mask="000" placeholder="CVV">
                            </label>
                            <i class="fas fa-lock"></i>
                        </div>
                    </div>
                    <div class="btn">Pay</div>
                </div>
            </div>
        </div>
    </div>

    <!-- <script>
        document.querySelector('input[type="submit"]').addEventListener('click', function(event) {
            document.getElementById('payment').style.display = 'block';
            event.preventDefault(); // Prevent the default form submission
        });

        document.querySelector('.btn').addEventListener('click', function() {
            // Submit the form using AJAX
            let formData = new FormData(document.getElementById('payment-form'));
            fetch('donate.php', {
                method: 'POST',
                body: formData
            }).then(response => {
                if (response.ok) {
                    window.location.href = 'successpay.php'; // Redirect to success page
                } else {
                    alert('Error processing payment. Please try again.');
                }
            });
        });
    </script> -->
    <script>
    document.querySelector('input[type="submit"]').addEventListener('click', function(event) {
        let bankName = document.getElementById('bank_name').value;
        let mobileNumber = document.getElementById('mobile_number').value;
        let amountToDonate = document.getElementById('amount_to_donate').value;
        let donorName = document.getElementById('donor_name').value;

        // Validate bank name
        if (bankName === "") {
            alert("Please select a bank.");
            event.preventDefault();
            return false;
        }

        // Validate mobile number
        if (mobileNumber === "" || !/^\d{10}$/.test(mobileNumber)) {
            alert("Please enter a valid 10-digit mobile number.");
            event.preventDefault();
            return false;
        }

        // Validate amount to donate
        if (amountToDonate === "" || isNaN(amountToDonate)) {
            alert("Please enter a valid amount to donate.");
            event.preventDefault();
            return false;
        }

        // Validate donor name
        if (donorName === "") {
            alert("Please enter your name.");
            event.preventDefault();
            return false;
        }

        document.getElementById('payment').style.display = 'block';
        event.preventDefault(); // Prevent the default form submission
    });

    document.querySelector('.btn').addEventListener('click', function() {
        // Payment form validation
        let cardHolderName = document.querySelector('.card .input').value;
        let cardNumber = document.querySelectorAll('.card .input')[1].value;
        let expiryDate = document.querySelector('.card-item:first-child .input').value;
        let cvv = document.querySelector('.card-item:last-child .input').value;

        // Validate card holder name
        if (cardHolderName === "") {
            alert("Please enter the card holder's name.");
            return false;
        }

        // Validate card number
        if (cardNumber === "" || !/^\d{4} \d{4} \d{4} \d{4}$/.test(cardNumber)) {
            alert("Please enter a valid card number.");
            return false;
        }

        // Validate expiry date (without space between month and year)
        if (expiryDate === "" || !/^\d{2}\/\d{2}$/.test(expiryDate)) {
        alert("Please enter a valid expiry date (MM/YY).");
        return false;
}


        // Validate CVV
        if (cvv === "" || !/^\d{3}$/.test(cvv)) {
            alert("Please enter a valid CVV.");
            return false;
        }

        // Submit the form using AJAX
        let formData = new FormData(document.getElementById('payment-form'));
        fetch('donate.php', {
            method: 'POST',
            body: formData
        }).then(response => {
            if (response.ok) {
                window.location.href = 'successpay.php'; // Redirect to success page
            } else {
                alert('Error processing payment. Please try again.');
            }
        });
    });
</script>


</body>
</html>
