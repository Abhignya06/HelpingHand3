<?php
session_start();
include 'connection.php';

if (isset($_POST['feedback'])) {
    $email = $_POST['email'];
    $name = $_POST['name'];
    $msg = $_POST['message'];
    $sanitized_emailid =  mysqli_real_escape_string($connection, $email);
    $sanitized_name =  mysqli_real_escape_string($connection, $name);
    $sanitized_msg =  mysqli_real_escape_string($connection, $msg);
    $query = "INSERT INTO user_feedback (name, email, message) VALUES ('$sanitized_name', '$sanitized_emailid', '$sanitized_msg')";
    $query_run = mysqli_query($connection, $query);
    if ($query_run) {
        echo '<script type="text/javascript">';
        echo 'console.log("Feedback added successfully!");';
        echo 'alert("Feedback added successfully!");';
        echo 'window.location.href = "contact1.html";';
        echo '</script>';
    } else {
        echo '<script type="text/javascript">';
        echo 'console.log("Failed to add feedback. Please try again.");';
        echo 'alert("Failed to add feedback. Please try again.");';
        echo 'window.location.href = "contact1.html";'; // Redirect to contact1.html
        echo '</script>';
    }
}
?>
